<?php /* /home/digit9ls/public_html/taxkamkar.com/resources/views/hra/create.blade.php */ ?>
<?php $__env->startSection('content'); ?>

<!-- ======= Breadcrumbs Section ======= -->
    <section class="breadcrumbs" style="margin-top:0px;	">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>HRA Caluclator</h2>
          <ol>
            <li><a href="index.html">Home</a></li>
            <li>HRA Caluclator</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs Section -->

<br>


<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<div class="container">    
    <div class="row">
	
	<div class="col-sm-7">
	
    <div id="signupbox" style=" margin-top:50px" class="">
        <div class="panel panel-info">
            <div class="panel-heading">
                <div class="panel-title"><b>HRA Exemption Calculator</b></div>
            </div>  
            <div class="panel-body" >
                            
					<form action="<?php echo e(route('hra.store')); ?>" method="post" class="form-horizontal main_form">
					<?php echo csrf_field(); ?>
                        <div id="div_id_name" class="form-group required"> 
                            <label for="id_name" class="control-label col-md-4  requiredField">Basic salary received<span class="asteriskField">*</span> </label> 
                            <div class="controls col-md-8 "> 
                                <input class="input-md textinput textInput form-control" id="id_name" name="basic_salary" placeholder="Basic salary received" style="margin-bottom: 10px" type="text" />
                            </div>
                        </div>
						<div id="div_id_name" class="form-group required"> 
                            <label for="id_name" class="control-label col-md-4  requiredField">Dearness Allowance (DA) received<span class="asteriskField">*</span> </label> 
                            <div class="controls col-md-8 "> 
                                <input class="input-md textinput textInput form-control" id="id_name" name="dearness_allowance" placeholder="Dearness Allowance (DA)" style="margin-bottom: 10px" type="text" />
                            </div>
                        </div>
						<div id="div_id_name" class="form-group required"> 
                            <label for="id_name" class="control-label col-md-4  requiredField">HRA received<span class="asteriskField">*</span> </label> 
                            <div class="controls col-md-8 "> 
                                <input class="input-md textinput textInput form-control" id="id_name" name="hra_recieved" placeholder="HRA received" style="margin-bottom: 10px" type="text" />
                            </div>
                        </div>
						<div id="div_id_name" class="form-group required"> 
                            <label for="id_name" class="control-label col-md-4  requiredField">Total Rent Paid<span class="asteriskField">*</span> </label> 
                            <div class="controls col-md-8 "> 
                                <input class="input-md textinput textInput form-control" id="id_name" name="total_rent_paid" placeholder="Total Rent Paid" style="margin-bottom: 10px" type="text" />
                            </div>
                        </div>
                        <div id="div_id_gender" class="form-group required">
                            <label for="id_gender"  class="control-label col-md-4  requiredField"> Do you live in Delhi, Mumbai, Kolkata or Chennai?<span class="asteriskField">*</span> </label>
                            <div class="controls col-md-8 "  style="margin-bottom: 10px">
                                 <label class="radio-inline"> <input type="radio" name="live_location" id="id_gender_1" value="yes"  style="margin-bottom: 10px">Yes</label>
                                 <label class="radio-inline"> <input type="radio" name="live_location" id="id_gender_2" value="no"  style="margin-bottom: 10px">No </label>
                            </div>
                        </div>
                        <div id="div_id_company" class="form-group required"> 
                            <label for="id_company" class="control-label col-md-4  requiredField">Enter your email address<span class="asteriskField">*</span> </label>
                            <div class="controls col-md-8 "> 
                                 <input class="input-md textinput textInput form-control" id="id_company" name="email_address" placeholder="your Email" style="margin-bottom: 10px" type="email" />
                            </div>
                        </div> 
                        
                        
                        <div class="form-group"> 
                            <div class="aab controls col-md-4 "></div>
                            <div class="controls col-md-8 ">
                                <button type="submit" class="btn btn-default"><i class="fa fa-arrow-right">&nbsp;SAVE</i></button>
                            </div>
                        </div> 
						
						<center>You can claim HRA while tax filing even if you have not submitted rent receipts to your HR. clearTax will help you claim this while e-filing.

<center>
                            

                </form>
            </div>
        </div>
    </div> 
</div>
<div class="col-sm-5">
<div class="" style=" margin-top:50px">

	<ul>
		<li>If you don't receive HRA, you can now claim upto Rs. 60,000 deduction under Section 80GG.</li>
		<br>
		<li>Click here to calculate your tax as per Budget 2020.</li>
		<br>
		<li>If you receive HRA, you can use this calculator.</li>
		<br>
	</ul>

</div>

</div>    


</div>


</div>            



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>