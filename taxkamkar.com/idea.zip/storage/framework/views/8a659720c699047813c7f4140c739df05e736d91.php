<?php /* C:\xampp\htdocs\tax\resources\views/admin/leave/index.blade.php */ ?>
<?php $__env->startSection('content'); ?>

    <div id="main-wrapper">
    <?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="page-wrapper">
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Leave Management</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('leave')); ?>">Leave</a></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>

            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <form action="<?php echo e(route('leave.search')); ?>" method="GET" class="form-horizontal">
                                <div class="card-body">
                                    <h4 class="card-title">Search</h4>
                                    <div class="form-group row">
                                        <label for="fname" class="col-sm-3 text-right control-label col-form-label">Search by leave type</label>
                                        <div class="col-sm-9">
                                            <input type="text" name="search" class="form-control" id="fname" placeholder="Leave type">
                                        </div>
                                    </div>
                                </div>
                                <div class="border-top">
                                    <div class="card-body">
                                        <button type="submit" class="btn btn-success">Search</button>
                                        <a href="<?php echo e(route('leave')); ?>" class="btn btn-md btn-danger">Clear</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-2">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isEmployee')): ?>
                        <a class="btn btn-lg btn-dark" href="<?php echo e(route('leave.create')); ?>">Apply leave</a>
                        <?php endif; ?>
                    </div>
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Leave List</h5>
                                <div class="table-responsive">
                                    <table id="zero_config" class="table table-striped table-bordered">
                                        <thead>
                                        <tr>
                                            <th>S.N.</th>
                                            <th>Employee name</th>
                                            <th>Leave type</th>
                                            <th>Date from</th>
                                            <th>Date to</th>
                                            <th>No. of days</th>
                                            <th>Reason</th>
                                            <th>Leave type offer</th>
                                            <th>Action</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $leaves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop -> index+1); ?></td>
                                                <td><?php echo e($leave->users->username); ?></td>
                                                <td><?php echo e($leave->leave_type); ?></td>
                                                <td><?php echo e($leave->date_from); ?></td>
                                                <td><?php echo e($leave->date_to); ?></td>
                                                <td><?php echo e($leave->days); ?></td>
                                                <td><?php echo e($leave->reason); ?></td>
                                                <td>
                                                    <?php if(Auth::user()->role=='admin'): ?>
                                                        
                                                        <?php if($leave->leave_type_offer==0): ?>
                                                            <form id="<?php echo e($leave->id); ?>" action="<?php echo e(route('leave.paid',$leave->id)); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                
                                                                <button type="submit" onclick="return confirm('Are you sure want to paid for leave?')" class="btn btn-sm btn-cyan" name="paid" value="1">Paid</button>
                                                            </form>
                                                            <form id="<?php echo e($leave->id); ?>" action="<?php echo e(route('leave.paid',$leave->id)); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                
                                                                <button type="submit" onclick="return confirm('Are you sure want to paid for leave?')" class="btn btn-sm btn-danger" name="paid" value="2">Unpaid</button>
                                                            </form>
                                                        <?php elseif($leave->leave_type_offer==1): ?>

                                                            <form action="<?php echo e(route('leave.paid',$leave->id)); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <button class="btn btn-sm btn-danger" onclick="return confirm('Are you sure want to unpaid for leave?')" type="submit" name="paid" value="2">Unpaid</button>
                                                            </form>
                                                        <?php else: ?>
                                                            <form action="<?php echo e(route('leave.paid',$leave->id)); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <button class="btn btn-sm btn-cyan" onclick="return confirm('Are you sure want to piad for leave?')" type="submit" name="paid" value="1">Paid</button>
                                                            </form>
                                                        <?php endif; ?>

                                                        
                                                        
                                                        
                                                    <?php else: ?>
                                                        <?php if($leave->leave_type_offer==0): ?>
                                                            <span class="badge badge-pill badge-warning">Pending</span>
                                                        <?php elseif($leave->leave_type_offer==1): ?>
                                                            <span class="badge badge-pill badge-success">Paid</span>
                                                        <?php else: ?>
                                                            <span class="badge badge-pill badge-danger">Unpaid</span>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                </td>

                                                        <td>
                                                            <?php if(Auth::user()->role=='admin'): ?>
                                                            
                                                            <?php if($leave->is_approved==0): ?>
                                                                <form id="approve-leave-<?php echo e($leave->id); ?>" action="<?php echo e(route('leave.approve',$leave->id)); ?>" method="POST">
                                                                    <?php echo csrf_field(); ?>
                                                                    
                                                                    <button type="submit" onclick="return confirm('Are you sure want to approve leave?')" class="btn btn-sm btn-cyan" name="approve" value="1">Approve</button>
                                                                </form>
                                                                <form id="reject-leave-<?php echo e($leave->id); ?>" action="<?php echo e(route('leave.approve',$leave->id)); ?>" method="POST">
                                                                    <?php echo csrf_field(); ?>
                                                                    
                                                                    <button type="submit" onclick="return confirm('Are you sure want to reject leave?')" class="btn btn-sm btn-danger" name="approve" value="2">Reject</button>
                                                                </form>
                                                            <?php elseif($leave->is_approved==1): ?>

                                                                <form action="<?php echo e(route('leave.approve',$leave->id)); ?>" method="POST">
                                                                    <?php echo csrf_field(); ?>
                                                                    <button class="btn btn-sm btn-danger" onclick="return confirm('Are you sure want to reject leave?')" type="submit" name="approve" value="2">Reject</button>
                                                                </form>
                                                            <?php else: ?>
                                                                <form action="<?php echo e(route('leave.approve',$leave->id)); ?>" method="POST">
                                                                    <?php echo csrf_field(); ?>
                                                                    <button class="btn btn-sm btn-cyan" onclick="return confirm('Are you sure want to approve leave?')" type="submit" name="approve" value="1">Approve</button>
                                                                </form>
                                                            <?php endif; ?>

                                                                
                                                                
                                                                
                                                                <?php else: ?>
                                                                <?php if($leave->is_approved==0): ?>
                                                                    <span class="badge badge-pill badge-warning">Pending</span>
                                                                <?php elseif($leave->is_approved==1): ?>
                                                                    <span class="badge badge-pill badge-success">Approved</span>
                                                                <?php else: ?>
                                                                    <span class="badge badge-pill badge-danger">Rejected</span>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                </td>
                                            </tr>
                                        </tbody>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                    <?php echo e($leaves->links()); ?>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <
            

            
                

                
                    
                        
                        
                        
                    

                    
                        
                        
                        
                        
                        
                        
                        
                    
                        
                            
                            
                        
                            
                            
                        
                            
                                
                                
                                
                            
                        
                    
                

            
            
                

                
                    
                        
                        
                        
                    

                    
                        
                        
                        
                        
                        
                        
                        
                    
                        
                            
                            
                        
                            
                            
                        
                            
                                
                                
                                
                            
                        
                    
                

            
            
            <footer class="footer text-center">
                All Rights Reserved by Taxkamkar. Ltd. Designed and Developed by <a href="https://www.digitalwebspot.com/">Digitalwebspot</a>.
            </footer>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>