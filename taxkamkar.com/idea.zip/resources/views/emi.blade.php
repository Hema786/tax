@extends('layouts.app')

@section('content')
<!-- ======= Hero Section ======= -->

<!-- ======= Breadcrumbs Section ======= -->
    <section class="breadcrumbs" style="margin-top:0px;	">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>EMI Caluclator</h2>
          <ol>
            <li><a href="index.html">Home</a></li>
            <li>EMI Caluclator</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs Section -->

<br>


<div id="outer">EMI Calculator<div id="cover"><form><table class="main"><col class="w50"><col class="w50"><tr><td>Loan Amount<td><input id="loan1"><tr><td>Repayment in months<td><input id="months1"><tr><td>Interest Rate<td><input id="rate1" onchange="emi();"><tr><td><button type="reset">Reset</button><td><button type="button" onclick='emi();'>Submit</button><tr><td>EMI<td><input id="pay1"><tr><td>Interest payable<td><input id="tintt1"><tr><td>Total payable<td><input id="gt1"></table></form></div></div>


<style>#outer{width:90%;max-width:600px;background:#fff;text-align:center;margin:0 auto;font-weight:500;}
#cover{border:2px solid #111;padding:15px 0}
.main{table-layout:fixed;width:94%;border:0;border-collapse:collapse;margin:0 auto;}
.main td{padding:0 8px;vertical-align:middle;text-align:left;border:0;font:500 16px arial}
.main input{width:100%;border:1px solid #ccc;margin:2px 0;padding:0 2%;height:22px;text-align:right;font-weight:400;font-size:14px;}
.main select{width:100%;border:1px solid #ccc;margin:2px 0;background:#fff;height:22px;font-weight:400;font-size:14px;}.w50{width:50%}.main button{width:100%;font-weight:500;margin:3px 0;}</style>

<script>function emi(){if(document.getElementById('loan1').value==null || document.getElementById('loan1').value.length==0 || document.getElementById('months1').value==null || document.getElementById('months1').value.length==0 || document.getElementById('rate1').value==null || document.getElementById('rate1').value.length==0 ) {document.getElementById('pay1').value='Data Reqd.';}else {var pay1='';var princ1= document.getElementById('loan1').value;var term1= document.getElementById('months1').value;var intr1=document.getElementById('rate1').value / 1200;document.getElementById('pay1').value =Math.round(princ1 * intr1 / (1-(Math.pow(1/(1 + intr1), term1)))*100)/100; document.getElementById('gt1').value= Math.round((document.getElementById('pay1').value * document.getElementById('months1').value)*100)/100;document.getElementById('tintt1').value=Math.round((document.getElementById('gt1').value*1 - document.getElementById('loan1').value*1)*100)/100;}}
// Widget Code by https://karvitt.com/widgets/
</script>

  
@endsection