@extends('layouts.app')

@section('content')

<!-- ======= Breadcrumbs Section ======= -->
    <section class="breadcrumbs" style="margin-top:0px;	">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Tax Planner</h2>
          <ol>
            <li><a href="index.html">Home</a></li>
            <li>Tax Planner</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs Section -->

<br>


<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-sm-12 text-center p-0 mt-3 mb-2">
            <div class="card px-0 pt-4 pb-0 mt-3 mb-3">
                <h2 id="heading">Tax Planner</h2>
                <p>We need the information to help you plan your taxes smartly</p>
                <form id="msform">
                    <!-- progressbar -->
                    <ul id="progressbar">
                        <li class="active" id="first"><strong>Personal Information</strong></li>
                        <li id="second"><strong>Income Details</strong></li>
                        <li id="third"><strong>Tax Saving Invest</strong></li>
                        <li id="fourth"><strong>Insurance</strong></li>
                        <li id="fifth"><strong>Analyse Tax Liability</strong></li>
                    </ul>
                    <div class="progress">
                        <div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar" aria-valuemin="0" aria-valuemax="100"></div>
                    </div> <br> <!-- fieldsets -->
                    
                    
                    <fieldset>
                        <div class="form-card">
                            <!---<div class="row">
                                <div class="col-7">
                                    <h2 class="fs-title">Account Information:</h2>
                                </div>
                                <div class="col-5">
                                    <h2 class="steps">Step 1 - 4</h2>
                                </div>
                            </div> --->
                            <div class="row">
                                <div class="col-4">
                                    <label class="fieldlabels">What's Your Age ?</label> 
                                    <input type="text" name="age" placeholder="What's Your Age ?" /> 
                                </div>
                                <div class="col-4">
                                    
                                </div>
                                <div class="col-4">
                                    
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-4">
                                    <label class="fieldlabels">Marital Status</label> 
                                <br>
                                <input type="radio" id="single" name="gender" value="single">
                                <label for="single">Single</label>
                                <input type="radio" id="Married" name="gender" value="Married">
                                <label for="Married">Married</label> 
                                </div>
                                <div class="col-4">
                                    
                                </div>
                                <div class="col-4">
                                    
                                </div>
                            </div>
                            
                                  
                                
                                
                                
                                 
                                
                                
                        </div> <input type="button" name="next" class="next action-button" value="Next" />
                    </fieldset>
                    <fieldset>
                        <div class="form-card">
                            <!---<div class="row">
                                <div class="col-7">
                                    <h2 class="fs-title">Personal Information:</h2>
                                </div>
                                <div class="col-5">
                                    <h2 class="steps">Step 2 - 4</h2>
                                </div>
                            </div>--->
                            <div class="row">
                                <div class="col-4">
                                    <label class="fieldlabels">Annual Income From All Sources</label> 
                                    <input type="text" name="anual_income" placeholder="Annual Income From All Sources" />
                                </div>
                                <div class="col-4">
                                    <label class="fieldlabels">Income On Interest From Deposits</label> 
                                    <input type="text" name="income_interest" placeholder="Income On Interest From Deposits" />
                                </div>
                                <div class="col-4">
                                    
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-4">
                                    <label class="fieldlabels">Enter Monthly Basic Salary</label> 
                                    <input type="text" name="monthly_salary" placeholder="Enter Monthly Basic Salary" />
                                </div>
                                <div class="col-4">
                                    <label class="fieldlabels">HRA As Part Of Your Salary (If Applicable)</label> 
                                    <input type="text" name="hra_salary" placeholder="HRA As Part Of Your Salary (If Applicable)" />
                                </div>
                                <div class="col-4">
                                    
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-4">
                                     <label class="fieldlabels">Monthly Rent Payable</label> 
                                    <input type="text" name="rent_payable" placeholder="Monthly Rent Payable" /> 
                                </div>
                                <div class="col-4">
                                    
                                </div>
                                <div class="col-4">
                                    
                                </div>
                            </div>
                           
                            
                            
                            
                            
                        </div> <input type="button" name="next" class="next action-button" value="Next" /> <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                    </fieldset>
                    <fieldset>
                        <div class="form-card">
                            <div class="row">
                                <div class="col-7">
                                    <h2 class="fs-title">Your Investment</h2>
                                </div>
                            </div> 
                            
                            <div class="row">
                                <div class="col-4">
                                    <label class="fieldlabels">EPF/PPF</label> 
                                    <input type="text" name="epf_ppf" placeholder="Enter EPF/PPF" />
                                </div>
                                <div class="col-4">
                                    <label class="fieldlabels">Tution Fees</label> 
                                    <input type="text" name="tution_fees" placeholder="Enter Tution Fees" />
                                </div>
                                <div class="col-4">
                                    <label class="fieldlabels">ELSS</label> 
                                    <input type="text" name="elss" placeholder="Enter ELSS" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-4">
                                    <label class="fieldlabels">NPS</label> 
                                    <input type="text" name="nps" placeholder="Enter NPS" />
                                </div>
                                <div class="col-4">
                                    <label class="fieldlabels">Other Investments</label> 
                                    <input type="text" name="other_investment" placeholder="Enter Other Investments (If Any)" />
                                </div>
                                <div class="col-4">
                            
                                </div>
                            </div>
                            
                            
                            <div class="row">
                                <div class="col-7">
                                    <h2 class="fs-title">Pension Contribution</h2>
                                </div>
                            </div> 
                            
                            
                            <div class="row">
                                <div class="col-4">
                                    <label class="fieldlabels">Employer's Contribution</label> 
                                    <input type="text" name="employers_contriution" placeholder="Enter Employer's Contribution" />
                                </div>
                                <div class="col-4">
                                    <label class="fieldlabels">Own Contribution</label> 
                                    <input type="text" name="own_Contribution" placeholder="Enter Own Contribution" />
                                </div>
                                <div class="col-4">
                            
                                </div>
                            </div>
                            
                            
                            <div class="row">
                                <div class="col-7">
                                    <h2 class="fs-title">Have Taken Home Loan?</h2>
                                </div>
                            </div> 
                            
                            
                            <div class="row">
                                <div class="col-4">
                                    <label class="fieldlabels">Principle Amount</label> 
                                    <input type="text" name="principle_amt" placeholder="Enter Principle Amount" />
                                </div>
                                <div class="col-4">
                                    <label class="fieldlabels">Interest Amount</label> 
                                    <input type="text" name="interest_amt" placeholder="Enter Interest Amount" />
                                </div>
                                <div class="col-4">
                            
                                </div>
                            </div>
                            
                            
                            <div class="row">
                                <div class="col-7">
                                    <h2 class="fs-title">Educational Loan</h2>
                                </div>
                            </div> 
                            
                            
                            <div class="row">
                                <div class="col-4">
                                    <label class="fieldlabels">Educational Loan</label> 
                                    <input type="text" name="edu_loan" placeholder="Enter Educational Loan" />
                                </div>
                                <div class="col-4">
                                   
                                </div>
                                <div class="col-4">
                            
                                </div>
                            </div>
                            
                        </div> <input type="button" name="next" class="next action-button" value="Next" /> <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                    
                    </fieldset>
                    <fieldset>
                        <div class="form-card">
                            
                            <div class="row">
                                <div class="col-4">
                                    <label class="fieldlabels">Life Insurance Premium</label> 
                                    <input type="text" name="life_insur_premium" placeholder="Enter Life Insurance Premium" />
                                </div>
                                <div class="col-4">
                                    <label class="fieldlabels">Health Insurance for Self and Family</label> 
                                    <input type="text" name="helath_insurance" placeholder="Enter Health Insurance for Self and Family" />
                                </div>
                                <div class="col-4">
                                    <label class="fieldlabels">Preventive Health Check-Ups</label> 
                                    <input type="text" name="preventive_health_chekup" placeholder="Enter Preventive Health Check-Ups" />
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-4">
                                    <label class="fieldlabels">Parents Health Insurance</label> 
                                    <input type="text" name="parent_health_insurance" placeholder="Enter Parents Health Insurance" />
                                </div>
                                <div class="col-4">
                                    
                                </div>
                                <div class="col-4">
                            
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-4">
                                    <label class="fieldlabels">Medical Expenditure Amount</label> 
                                    <input type="text" name="medical_expenditure" placeholder="Enter Medical Expenditure Amount" />
                                </div>
                                <div class="col-4">
                                    
                                </div>
                                <div class="col-4">
                            
                                </div>
                            </div>
                            
                        
                            
                        </div> <input type="button" name="next" class="next action-button" value="Analyse Tax Liability" /> <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                    
                    </fieldset>
                    
                    <fieldset>
                        <div class="form-card">
                             <br>
                            
                             <br>
                            <div class="row justify-content-center">
                                <div class="col-7 text-center">
                                    <h2 class="purple-text text-center">Congratulation you have already saved your taxes with your current Investments</h2>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>
</div> 



<script>
    $(document).ready(function(){

var current_fs, next_fs, previous_fs; //fieldsets
var opacity;
var current = 1;
var steps = $("fieldset").length;

setProgressBar(current);

$(".next").click(function(){

current_fs = $(this).parent();
next_fs = $(this).parent().next();

//Add Class Active
$("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

//show the next fieldset
next_fs.show();
//hide the current fieldset with style
current_fs.animate({opacity: 0}, {
step: function(now) {
// for making fielset appear animation
opacity = 1 - now;

current_fs.css({
'display': 'none',
'position': 'relative'
});
next_fs.css({'opacity': opacity});
},
duration: 500
});
setProgressBar(++current);
});

$(".previous").click(function(){

current_fs = $(this).parent();
previous_fs = $(this).parent().prev();

//Remove class active
$("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");

//show the previous fieldset
previous_fs.show();

//hide the current fieldset with style
current_fs.animate({opacity: 0}, {
step: function(now) {
// for making fielset appear animation
opacity = 1 - now;

current_fs.css({
'display': 'none',
'position': 'relative'
});
previous_fs.css({'opacity': opacity});
},
duration: 500
});
setProgressBar(--current);
});

function setProgressBar(curStep){
var percent = parseFloat(100 / steps) * curStep;
percent = percent.toFixed();
$(".progress-bar")
.css("width",percent+"%")
}

$(".submit").click(function(){
return false;
})

});
</script>


<style>
    #heading {
    text-transform: uppercase;
    color: #335eea;
    font-weight: normal
}

#msform {
    text-align: center;
    position: relative;
    margin-top: 20px
}

#msform fieldset {
    background: white;
    border: 0 none;
    border-radius: 0.5rem;
    box-sizing: border-box;
    width: 80%;
    margin: 0px auto;
    padding-bottom: 20px;
    position: relative
}

.form-card {
    text-align: left
}

#msform fieldset:not(:first-of-type) {
    display: none
}

#msform input,
#msform textarea {
    padding: 8px 15px 8px 15px;
    border: 1px solid #ccc;
    border-radius: 0px;
    margin-bottom: 25px;
    margin-top: 2px;
    width: 100%;
    box-sizing: border-box;
    color: #2C3E50;
    background-color: transparent;
    font-size: 16px;
    letter-spacing: 1px
}

#msform input[type=checkbox], input[type=radio] {
    width: auto !important;
}

#msform input:focus,
#msform textarea:focus {
    -moz-box-shadow: none !important;
    -webkit-box-shadow: none !important;
    box-shadow: none !important;
    border: 1px solid #335eea;
    outline-width: 0
}

#msform .action-button {
    width: auto;
    background: #335eea;
    font-weight: bold;
    color: white;
    border: 0 none;
    border-radius: 0px;
    cursor: pointer;
    padding: 10px 5px;
    margin: 10px 0px 10px 5px;
    float: right
}

#msform .action-button:hover,
#msform .action-button:focus {
    background-color: #311B92
}

#msform .action-button-previous {
    width: 100px;
    background: #616161;
    font-weight: bold;
    color: white;
    border: 0 none;
    border-radius: 0px;
    cursor: pointer;
    padding: 10px 5px;
    margin: 10px 5px 10px 0px;
    float: right
}

#msform .action-button-previous:hover,
#msform .action-button-previous:focus {
    background-color: #000000
}

.card {
    z-index: 0;
    border: none;
    position: relative
}

.fs-title {
    font-size: 25px;
    color: #335eea;
    margin-bottom: 15px;
    font-weight: normal;
    text-align: left
}

.purple-text {
    color: #335eea;
    font-weight: normal
}

.steps {
    font-size: 25px;
    color: gray;
    margin-bottom: 10px;
    font-weight: normal;
    text-align: right
}

.fieldlabels {
    color: gray;
    text-align: left
}

#progressbar {
    margin-bottom: 30px;
    overflow: hidden;
    color: lightgrey
}

#progressbar .active {
    color: #335eea
}

#progressbar li {
    list-style-type: none;
    font-size: 15px;
    width: 19%;
    float: left;
    position: relative;
    font-weight: 400
}

#progressbar #first:before {
    font-family: FontAwesome;
    /*content: "\f00c"*/
    content: "1";
}

#progressbar #second:before {
    font-family: FontAwesome;
    content: "2";
}

#progressbar #third:before {
    font-family: FontAwesome;
    content: "3";
}

#progressbar #fourth:before {
    font-family: FontAwesome;
    content: "4";
}
#progressbar #fifth:before {
    font-family: FontAwesome;
    content: "5";
}


#progressbar li:before {
    width: 50px;
    height: 50px;
    line-height: 45px;
    display: block;
    font-size: 20px;
    color: #ffffff;
    background: lightgray;
    border-radius: 50%;
    margin: 0 auto 10px auto;
    padding: 2px
}

#progressbar li:after {
    content: '';
    width: 100%;
    height: 2px;
    background: lightgray;
    position: absolute;
    left: 0;
    top: 25px;
    z-index: -1
}

#progressbar li.active:before,
#progressbar li.active:after {
    background: #335eea
}

.progress {
    height: 6px
}

.progress-bar {
    background-color: #335eea
}

.fit-image {
    width: 100%;
    object-fit: cover
}
</style>



@endsection