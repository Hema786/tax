<?php /* C:\xampp\htdocs\tax\resources\views/taxfilling.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <form action="<?php echo e(route('salary.store')); ?>" method="post" class="form-horizontal">
                            <?php echo csrf_field(); ?>
                            <div class="card-body">
                                <h4 class="card-title">Add Salary</h4>
                                <div class="form-group row">
                                    <label for="fname" class="col-sm-3 text-right control-label col-form-label">Employee name</label>
                                    <div class="col-sm-9">
                                        <select type="text" name="employee_name" class="form-control" id="fname" placeholder="Enter a salary amount">
                                            
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="fname" class="col-sm-3 text-right control-label col-form-label">Salary Amount</label>
                                    <div class="col-sm-9">
                                        <input type="text" name="salary_amount" class="form-control" id="fname" placeholder="Enter a salary amount">
                                    </div>
                                </div>
                            </div>
                            <div class="border-top">
                                <div class="card-body">
                                    <button type="submit" class="btn btn-dark">Add</button>
                                </div>
                            </div>
                        </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>