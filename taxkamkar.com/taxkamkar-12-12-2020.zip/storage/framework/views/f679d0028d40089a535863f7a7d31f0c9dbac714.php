<?php $__env->startSection('content'); ?>

<!-- ======= Breadcrumbs Section ======= -->
    <section class="breadcrumbs" style="margin-top:0px;	">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Get Plan</h2>
          <ol>
            <li><a href="/">Home</a></li>
            <li>Pricing</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs Section -->

<br>

<!------ Include the above in your HEAD tag ---------->

<div class="container">    
    <div class="row">
        <div id="bookagent" class="tabcontent">
            <div class="wrapper">
                <?php echo csrf_field(); ?>
                <?php
                    $i = 1
                ?>
                <?php $__currentLoopData = $pricingData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pricing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="package <?php echo e($pricing->recommended); ?>">
                    <div class="name"><?php echo e($pricing->title); ?></div>
                    <div class="price">₹<?php echo e($pricing->price); ?></div>
                    <div class="trial"><?php if($pricing->tenure == 0): ?> Lifetime <?php else: ?> <?php echo e($pricing->tenure); ?> <?php endif; ?></div>
                    <hr>
                    <ul>
                        <?php if($pricing->line1 != ""): ?>
                        <li><?php echo e($pricing->line1); ?></li>
                        <?php endif; ?>
                        <?php if($pricing->line2 != ""): ?>
                        <li><?php echo e($pricing->line2); ?></li>
                        <?php endif; ?>
                        <?php if($pricing->line3 != ""): ?>
                        <li><?php echo e($pricing->line3); ?></li>
                        <?php endif; ?>
                        <?php if($pricing->line4 != ""): ?>
                        <li><?php echo e($pricing->line4); ?></li>
                        <?php endif; ?>
                        <?php if($pricing->line5 != ""): ?>
                        <li><?php echo e($pricing->line5); ?></li>
                        <?php endif; ?>
                        <?php if($pricing->line6 != ""): ?>
                        <li><?php echo e($pricing->line6); ?></li>
                        <?php endif; ?>
                    </ul>
                    <a class="pricing_anchor" href="purchase_plan?id=<?php echo e($pricing->id); ?>">
                        <button class="btn btn-primary">Purchanse</button>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/digit9ls/public_html/taxkamkar.com/resources/views/pricing/index.blade.php ENDPATH**/ ?>