<?php $__env->startSection('content'); ?>

<style>
    .question-quiz {
        list-style:none;
        margin: 0 0 20px;
    }
    .question-quiz label {
        display:inline;
        font-size:14px;
    }
    .mr5{
        margin-bottom:5px;
    }
    .green {
        background-color: seagreen;
        padding: 5px;
        border-radius: 5px;
    }
    .red {
        background-color: indianred;
        padding: 5px;
        border-radius: 5px;
    }
    .green label {
        color: white;
    }
    .red label {
        color: white;
    }
    #quiz_result {
        padding: 20px;
        background-color: #007bff;
        color: white;
        margin-bottom: 20px;
        border-radius: 10px;
        display:none;
    }
    .retry{
        float: right;
        border: solid 1px white;
        padding: 8px;
        color: black;
        font-size: 13px;
        border-radius: 4px;
        background-color: white;
        margin-top: -6px;
    }
</style>
 
<div class="container" id="scrollhere">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" style="background: transparent !important;
    box-shadow: 0px 9px 12px 4px #ccc;">
                <div class="card-header">
                    <center>
                        <h5>How well do you understand Tax System?</h5>
                    </center>
                </div>

                <div class="card-body">
                    <div method="post" id="quiz" name="form">
                        <div class="quiz" id="quiz_container">
                            <div id="quiz_result">
                                <span>Correct Answers: </span><span id="correct_count">3</span><span>/5</span>
                                <a class="retry" href="<?php echo e(url('faq')); ?>">Retry</a>
                            </div>
                            <?php echo csrf_field(); ?>
                            <?php
                                $i = 1
                            ?>
                            <?php $__currentLoopData = $questionData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="question-quiz">
                                    <!--Question-->
                                    <h6><?php echo e($question->question); ?></h6>
                                    <!--Options-->
                                    <?php if($question->answer1 != '' || $question->answer1 != null): ?>
                                    <div class="mr5">
                                        <input type="radio" <?php if($question->answer == $question->answer1): ?> data-correct="true" <?php endif; ?> name="<?php echo e($i); ?>-answers" data-id="<?php echo e($i); ?>-answers-A" value="<?php echo e($question->answer1); ?>" />
                                        <label for="<?php echo e($question->id); ?>-answers-A">A) <?php echo e($question->answer1); ?> </label>
                                    </div>
                                    <?php endif; ?>
                                    <?php if($question->answer2 != '' || $question->answer2 != null): ?>
                                    <div class="mr5">
                                        <input type="radio" <?php if($question->answer == $question->answer2): ?> data-correct="true" <?php endif; ?> name="<?php echo e($i); ?>-answers" data-id="<?php echo e($i); ?>-answers-B" value="<?php echo e($question->answer2); ?>" />
                                        <label for="<?php echo e($question->id); ?>-answers-A">B) <?php echo e($question->answer2); ?> </label>
                                    </div>
                                    <?php endif; ?>
                                    <?php if($question->answer3 != '' || $question->answer3 != null): ?>
                                    <div class="mr5">
                                        <input type="radio" <?php if($question->answer == $question->answer3): ?> data-correct="true" <?php endif; ?> name="<?php echo e($i); ?>-answers" data-id="<?php echo e($i); ?>-answers-C" value="<?php echo e($question->answer3); ?>" />
                                        <label for="<?php echo e($question->id); ?>-answers-A">C) <?php echo e($question->answer3); ?> </label>
                                    </div>
                                    <?php endif; ?>
                                    <?php if($question->answer4 != '' || $question->answer4 != null): ?>
                                    <div class="mr5">
                                        <input type="radio" <?php if($question->answer == $question->answer4): ?> data-correct="true" <?php endif; ?> name="<?php echo e($i); ?>-answers" data-id="<?php echo e($i); ?>-answers-D" value="<?php echo e($question->answer4); ?>" />
                                        <label for="<?php echo e($question->id); ?>-answers-A">D) <?php echo e($question->answer4); ?> </label>
                                    </div>
                                    <?php endif; ?>
                                </li>
                                <?php
                                    $i++
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-8 offset-md-4">
                                <button onclick="calc_result()" type="submit" class="btn btn-primary">Submit Quiz</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/digit9ls/public_html/taxkamkar.com/resources/views/faq/index.blade.php ENDPATH**/ ?>