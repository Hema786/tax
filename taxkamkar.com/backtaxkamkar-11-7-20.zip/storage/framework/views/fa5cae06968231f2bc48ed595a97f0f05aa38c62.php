<?php /* C:\xampp\htdocs\tax\vendor\maddhatter\laravel-fullcalendar\src\MaddHatter\LaravelFullcalendar/../../views//script.blade.php */ ?>
<script>
    $(document).ready(function(){
        $('#calendar-<?php echo e($id); ?>').fullCalendar(<?php echo $options; ?>);
    });
</script>
