<?php /* /home/digit9ls/public_html/taxkamkar.com/resources/views/admin/taxer/index.blade.php */ ?>
<?php $__env->startSection('content'); ?>

    <div id="main-wrapper">
    <?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="page-wrapper">
            <div class="page-breadcrumb">
                <div class="row">
                    <div class="col-12 d-flex no-block align-items-center">
                        <h4 class="page-title">Tax Management</h4>
                        <div class="ml-auto text-right">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('taxer')); ?>">tax</a></li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>

            <div class="container-fluid">
                <div class="row">
                    
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Tax List</h5>
                                <div class="table-responsive">
                                    <table id="zero_config" class="table table-striped table-bordered">
                                        <thead>
                                        <tr>
                                            <th>S.N.</th>
                                            <th>First name</th>
											<th>Middle name</th>
											<th>Last name</th>
											<th>Gender</th>
                                            
                                            <!---<th>Action</th>--->
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $taxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop -> index+1); ?></td>
                                                <td><?php echo e($salary ->first_name); ?></td>
                                                <td><?php echo e($salary->middle_name); ?></td>
												<td><?php echo e($salary->last_name); ?></td>
												<td><?php echo e($salary->gender); ?></td>
                                               <!--- <td>
                                                    <form action="<?php echo e(route('taxer.delete',$salary->id)); ?>" method="put">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <a href="<?php echo e(route('taxer.edit',$salary->id)); ?>" class="btn btn-sm btn-dark">Edit</a>
                                                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                                                    </form>
                                                </td>--->
                                            </tr>
                                        </tbody>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                    <?php echo e($taxes->links()); ?>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <footer class="footer text-center">
                All Rights Reserved by Taxkamkar. Ltd. Designed and Developed by <a href="https://www.digitalwebspot.com/">Digitalwebspot</a>.
            </footer>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>